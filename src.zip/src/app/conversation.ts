export class Conversation{
    outText:string;
    inText:string;
    constructor(){
        this.outText="";
        this.inText="";
    }
}